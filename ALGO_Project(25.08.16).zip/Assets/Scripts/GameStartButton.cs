using UnityEngine;

public class GameStartButton : MonoBehaviour
{
    public GameObject minigameManager; // MinigameManager 오브젝트 연결

    public void StartGame()
    {
        minigameManager.SetActive(true); // 오브젝트 켜기
        minigameManager.GetComponent<MinigameManager>().InitializeGame(); // 초기화 실행

    }
}
