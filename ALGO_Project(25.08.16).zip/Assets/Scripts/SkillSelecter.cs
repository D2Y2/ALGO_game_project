using UnityEngine;
using UnityEngine.UI;
using System.Collections.Generic;

public class SkillSelector : MonoBehaviour
{
    public GameObject[] skillIcons; // SkillIcon1 ~ SkillIcon5
    public GameObject[] skillCountPrefabs; // SkillCount1 ~ SkillCount5
    private List<int> selectedSkills = new List<int>();
    private Dictionary<int, GameObject> skillCountInstances = new Dictionary<int, GameObject>();

    private void Start()
    {
        for (int i = 0; i < skillIcons.Length; i++)
        {
            int index = i;
            Button btn = skillIcons[i].GetComponent<Button>();
            if (btn != null)
                btn.onClick.AddListener(() => OnSkillClicked(index));
        }
    }

    void OnSkillClicked(int index)
    {
        if (selectedSkills.Contains(index))
        {
            // 해제
            selectedSkills.Remove(index);
            Destroy(skillCountInstances[index]);
            skillCountInstances.Remove(index);
            UpdateSkillCounts();
        }
        else
        {
            // 선택
            selectedSkills.Add(index);
            int order = selectedSkills.Count;
            var countObj = Instantiate(skillCountPrefabs[order - 1], skillIcons[index].transform, false);
            countObj.GetComponent<RectTransform>().anchoredPosition = new Vector2(25, 25);
            skillCountInstances[index] = countObj;
        }
    }

    void UpdateSkillCounts()
    {
        for (int i = 0; i < selectedSkills.Count; i++)
        {
            int skillIndex = selectedSkills[i];
            Destroy(skillCountInstances[skillIndex]);
            var newObj = Instantiate(skillCountPrefabs[i], skillIcons[skillIndex].transform, false);
            newObj.GetComponent<RectTransform>().anchoredPosition = new Vector2(25, 25);
            skillCountInstances[skillIndex] = newObj;
        }
    }

    public List<int> GetSelectedSkills()
    {
        return new List<int>(selectedSkills);
    }
}
