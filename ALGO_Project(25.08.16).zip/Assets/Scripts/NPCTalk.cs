using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI; // UI 사용 위해 필요

public class NPCInteraction : MonoBehaviour
{
    private bool isPlayerNear = false;
    public GameObject interactText; // "E: 상호작용" UI

    void Start()
    {
        // 처음에는 숨김
        interactText.SetActive(false);
    }

    void Update()
    {
        // 근처일 때 UI 표시
        interactText.SetActive(isPlayerNear);

        // E 키 눌렀을 때 씬 전환
        if (isPlayerNear && Input.GetKeyDown(KeyCode.E))
        {
            SceneManager.LoadScene("Fight");
        }
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.CompareTag("Player"))
        {
            isPlayerNear = true;
        }
    }

    private void OnTriggerExit2D(Collider2D other)
    {
        if (other.CompareTag("Player"))
        {
            isPlayerNear = false;
        }
    }
}
