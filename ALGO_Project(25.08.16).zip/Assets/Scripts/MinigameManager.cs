using UnityEngine;
using TMPro;

public class MinigameManager : MonoBehaviour
{
    [Header("UI References")]
    public RectTransform backgroundBar;
    public RectTransform movingElement;
    public RectTransform successZone;
    public TextMeshProUGUI resultText;

    [Header("Movement Settings")]
    public float moveSpeed = 300f;
    private int moveDirection = 1;
    private float currentXPosition;

    [Header("Game Settings")]
    public KeyCode actionKey = KeyCode.Space;
    public float successZoneWidth = 100f;
    public int maxTraversals = 4;
    private int currentTraversals;

    private bool isGameActive = false;

    private float backgroundBarWidth;
    private float movingElementHalfWidth;

    void Start()
    {
        // 게임 시작 전에는 아무 일도 하지 않음
        isGameActive = false;
        resultText.text = "";
    }

    void Update()
    {
        if (!isGameActive) return;

        HandleMovingElementMovement();
        HandlePlayerInput();
    }

    public void InitializeGame()
    {
        // ★ UI 레이아웃을 강제로 업데이트하여 정확한 너비를 가져옵니다.
        Canvas.ForceUpdateCanvases();

        // UI 너비 계산
        backgroundBarWidth = backgroundBar.rect.width;
        movingElementHalfWidth = movingElement.rect.width / 2f;

        // 성공 존 너비 설정
        successZone.SetSizeWithCurrentAnchors(RectTransform.Axis.Horizontal, successZoneWidth);

        // 초기 위치 왼쪽 끝
        currentXPosition = -backgroundBarWidth / 2f + movingElementHalfWidth;
        movingElement.anchoredPosition = new Vector2(currentXPosition, 0);

        // 항상 오른쪽으로 이동 시작
        moveDirection = 1;

        currentTraversals = 0;
        resultText.text = "";
        isGameActive = true;

        Debug.Log("미니게임 시작! " + actionKey.ToString() + " 키를 눌러 타이밍을 맞춰보세요.");
    }

    void HandleMovingElementMovement()
    {
        // 위치 갱신
        currentXPosition += moveDirection * moveSpeed * Time.deltaTime;

        float maxX = (backgroundBarWidth / 2f) - movingElementHalfWidth;
        float minX = -(backgroundBarWidth / 2f) + movingElementHalfWidth;

        bool directionChanged = false;

        if (currentXPosition >= maxX)
        {
            currentXPosition = maxX;
            moveDirection = -1;
            directionChanged = true;
        }
        else if (currentXPosition <= minX)
        {
            currentXPosition = minX;
            moveDirection = 1;
            directionChanged = true;
        }

        if (directionChanged)
        {
            currentTraversals++;
            if (currentTraversals >= maxTraversals)
            {
                EndGame(false);
                return;
            }
        }

        movingElement.anchoredPosition = new Vector2(currentXPosition, 0);
    }

    void HandlePlayerInput()
    {
        if (Input.GetKeyDown(actionKey))
        {
            CheckSuccess();
        }
    }

    void CheckSuccess()
    {
        float currentElementX = movingElement.anchoredPosition.x;
        float successZoneMinX = successZone.anchoredPosition.x - (successZone.rect.width / 2f);
        float successZoneMaxX = successZone.anchoredPosition.x + (successZone.rect.width / 2f);

        if (currentElementX >= successZoneMinX && currentElementX <= successZoneMaxX)
        {
            EndGame(true);
        }
        else
        {
            EndGame(false);
        }
    }

    void EndGame(bool success)
    {
        isGameActive = false;

        if (success)
        {
            resultText.color = Color.green;
            resultText.text = "Success!";
            Debug.Log("미니게임 성공!");
        }
        else
        {
            resultText.color = Color.red;
            resultText.text = "Fail!";
            Debug.Log("미니게임 실패!");
        }

        // 3초 후 초기화
        Invoke("RestartGame", 3f);
    }

    void RestartGame()
    {
        isGameActive = false;
        resultText.text = "";
        movingElement.anchoredPosition = Vector2.zero;
    }
}